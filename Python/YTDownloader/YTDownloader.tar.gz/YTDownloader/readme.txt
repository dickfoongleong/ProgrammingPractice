This program will work for Mac user.
It downloads the list of musics from INPUT_FILE and move to Mac Music App library.

Input file format:
  - Plain text document
  - URL [|| OPTIONAL_CUSTOM_NAME]

To run the program with custom input file:
  - python3 YouTubeDL.py <input_file_path>

To run the program with defaul input file:
  - python3 YouTubeDL.py
